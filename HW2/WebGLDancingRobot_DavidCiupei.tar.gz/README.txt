David Ciupei 
Email: david.ciupei@wsu.edu
SID: 11383576

Description:
	This program will build a dancing robot using hierarchical modeling and object instancing in WebGL and JavaScript. There will be joints for both shoulders, elbows, wrist, and ankle joints. The joints will be represented by circles and the rest of the body by various polygons.The joints will have different angles and speeds giving the robot a dancing behavior. The WebGL.js file was written by Professor Wayne O. Cochran and the html file for his robot arm was also used in developing the robot. 

Run:
	This was programmed using WebStorm and to run it you just have to make sure the WebGL.js file is called in the html file then just simply click on one of the web browser options within the screen. Once the html file is loaded the robot will be in a fixed standing position and to make the robot dance just click on the robot.

File:
- WebGL.js
- animation.html
- README.txt
